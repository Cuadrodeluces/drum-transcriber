# Drum Transcriber MP3 (backend experimental)

Servicio independiente para probar DrumScript sin modificar la web actual.

## Despliegue en Render

1. En Render crea un **New Web Service** conectado al repositorio `Cuadrodeluces/drum-transcriber`.
2. Configura **Root Directory** como `backend-mp3`.
3. Runtime: Python; Build Command: `pip install -r requirements.txt`; Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`.
4. Selecciona Free para la primera prueba. Si el servicio no puede instalar o ejecutar Demucs/PyTorch por los límites de recursos, no cambies a un plan de pago: detén la prueba y revisa alternativas gratuitas.
5. Comprueba `/health`: debe responder con `{"ok":true,"engine":"DrumScript","input":"mp3"}`.
6. Prueba primero un MP3 corto de 15–30 segundos y confirma que descarga un PDF o un ZIP con los resultados.

## Qué hace

- Acepta MP3 y comprueba tamaño y compás.
- Llama a DrumScript con `full_song=True`.
- Ofrece una vista preliminar de eventos, PDF si DrumScript lo genera y ZIP de archivos.
- Mantiene este backend separado de la web actual para no romperla.

## Límites conocidos

DrumScript 0.2.1 está en fase alfa. La vista SVG es solo una representación preliminar de golpes, no una partitura musical grabada profesionalmente. La separación Demucs/PyTorch puede exceder recursos de una instancia gratuita. El alojamiento gratuito puede suspenderse por inactividad y el almacenamiento temporal no es permanente. No se garantiza todavía precisión de transcripción.
