import json
import os
import shutil
import tempfile
import uuid
import zipfile
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
import drumscript as ds

APP_DIR = Path(__file__).parent
TMP_ROOT = Path(tempfile.gettempdir()) / "drum-transcriber-jobs"
TMP_ROOT.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "30")) * 1024 * 1024

app = FastAPI(title="Drum Transcriber MP3", version="1.1.1")


@app.get("/", response_class=HTMLResponse)
def home():
    return (APP_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"ok": True, "engine": "DrumScript", "input": "mp3"}


def clean_job(job_id: str):
    shutil.rmtree(TMP_ROOT / job_id, ignore_errors=True)
    try:
        (TMP_ROOT / f"{job_id}.zip").unlink(missing_ok=True)
    except OSError:
        pass


@app.post("/api/transcribe")
def transcribe(file: UploadFile = File(...), time_signature: str = "4/4"):
    filename = (file.filename or "").lower()
    if not filename.endswith(".mp3"):
        raise HTTPException(status_code=415, detail="Solo se aceptan archivos MP3.")
    if time_signature not in {"4/4", "3/4", "6/8", "5/4", "7/8"}:
        raise HTTPException(status_code=400, detail="Compás no admitido.")

    job_id = uuid.uuid4().hex
    job_dir = TMP_ROOT / job_id
    job_dir.mkdir(parents=True, exist_ok=False)
    input_path = job_dir / "audio.mp3"
    out_dir = job_dir / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        total = 0
        with input_path.open("wb") as out:
            while True:
                chunk = file.file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_UPLOAD_BYTES:
                    raise HTTPException(
                        status_code=413,
                        detail=f"El MP3 supera el límite de {MAX_UPLOAD_BYTES // (1024 * 1024)} MB."
                    )
                out.write(chunk)
        if total == 0:
            raise HTTPException(status_code=400, detail="El archivo está vacío.")

        result = ds.transcribe(
            str(input_path),
            full_song=True,
            time_signature=time_signature,
            output_dir=str(out_dir),
            output_filename="bateria",
            verbose=True,
        )
        if not isinstance(result, dict):
            raise RuntimeError("DrumScript no devolvió los resultados esperados.")

        events = result.get("events", [])
        tempo = float(result.get("tempo") or 120)
        normalised = []
        for ev in events:
            try:
                t = float(ev.get("time_sec", ev.get("time", 0)))
                inst = ev.get("instruments", ["unknown"])
                if isinstance(inst, str):
                    inst = [inst]
                normalised.append({
                    "time": max(0, t),
                    "instruments": [str(x) for x in inst]
                })
            except (TypeError, ValueError, AttributeError):
                continue
        normalised.sort(key=lambda e: e["time"])

        warning = (
            "Transcripción automática preliminar. Revisa especialmente los golpes suaves, "
            "los platos y los cambios de tempo o compás."
        )
        score_data = {
            "tempo": tempo,
            "time_signature": time_signature,
            "duration": normalised[-1]["time"] if normalised else 0,
            "events": normalised,
            "warning": warning,
        }
        (out_dir / "score.json").write_text(
            json.dumps(score_data, ensure_ascii=False), encoding="utf-8"
        )

        pdf_path = result.get("pdf_path")
        if not pdf_path:
            candidates = list(out_dir.glob("*.pdf"))
            pdf_path = str(candidates[0]) if candidates else None
        stem_path = result.get("drum_stem_path")

        zip_path = TMP_ROOT / f"{job_id}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in out_dir.rglob("*"):
                if p.is_file():
                    zf.write(p, arcname=p.relative_to(out_dir))
            if stem_path and Path(stem_path).is_file():
                zf.write(stem_path, arcname="bateria_separada.wav")

        if not zip_path.exists() or not zip_path.stat().st_size:
            raise RuntimeError("No se pudo preparar el paquete de resultados.")

        return JSONResponse({
            "job_id": job_id,
            "tempo": tempo,
            "time_signature": time_signature,
            "events": normalised,
            "warning": warning,
            "pdf_available": bool(pdf_path and Path(pdf_path).is_file()),
            "download_url": f"/api/download/{job_id}",
            "event_count": len(normalised),
        })
    except HTTPException:
        clean_job(job_id)
        raise
    except Exception as exc:
        clean_job(job_id)
        raise HTTPException(
            status_code=500,
            detail=f"El análisis falló: {type(exc).__name__}: {str(exc)[:400]}"
        ) from exc
    finally:
        file.file.close()


@app.get("/api/download/{job_id}")
def download(job_id: str):
    if not job_id.isalnum() or len(job_id) != 32:
        raise HTTPException(status_code=404, detail="Resultado no encontrado.")
    path = TMP_ROOT / f"{job_id}.zip"
    if not path.is_file():
        raise HTTPException(
            status_code=404,
            detail="El resultado ya no está disponible; vuelve a analizar el MP3."
        )
    return FileResponse(
        path, media_type="application/zip", filename="transcripcion_bateria.zip"
    )


@app.get("/api/pdf/{job_id}")
def download_pdf(job_id: str):
    if not job_id.isalnum() or len(job_id) != 32:
        raise HTTPException(status_code=404, detail="Resultado no encontrado.")
    pdfs = list((TMP_ROOT / job_id / "outputs").glob("*.pdf"))
    if not pdfs:
        raise HTTPException(
            status_code=404,
            detail="DrumScript no generó un PDF en este análisis. Descarga el ZIP para revisar los demás resultados."
        )
    return FileResponse(
        pdfs[0], media_type="application/pdf", filename="partitura_bateria.pdf"
    )
